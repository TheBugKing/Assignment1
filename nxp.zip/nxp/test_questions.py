"""End-to-end test runner: hit /query for each test question and write a report.

Run from the rag_nxp directory while uvicorn is up on http://localhost:8000.

Examples:
    python test_questions.py                    # all 14 questions
    python test_questions.py --tiers T1         # only Tier 1 (basic)
    python test_questions.py --tiers T1,T5      # basic + edge cases
    python test_questions.py --limit 5          # first 5 questions only

Tiers:
    T1 basic       : Preamble goals, Senator term, Presidential age
    T2 numerical   : amendment ratification, senators/state, veto override
    T3 clause      : impeachment power, impeachment trial, treason proof
    T4 reasoning   : senator-as-elector, pocket-/auto-signed bill, no electoral majority
    T5 edge        : political parties (not mentioned), amendments not in this PDF

Outputs (overwritten each run):
- test_results.md   : human-readable per-question verdict
- test_results.json : raw API responses (one per question)
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

API_URL = "http://localhost:8000/query"
TIMEOUT_S = 240

NOT_FOUND = "This information is not present in the document"


@dataclass
class Q:
    tier: str
    qid: str
    question: str
    expect_kind: str  # "factoid" | "synthesis" | "clause" | "reasoning" | "edge"
    must_contain_any: list[str] = field(default_factory=list)
    must_refuse: bool = False
    accept_refuse: bool = False  # PASS if EITHER refusal OR keyword match
    notes: str = ""
    session_id: str | None = None


QUESTIONS: list[Q] = [
    # Tier 1 - basic factoid
    Q("T1 basic", "T1.1",
      "What are the six goals stated in the Preamble?",
      "synthesis",
      # The canonical six goals plus tolerant paraphrases. The model often
      # rephrases "insure domestic Tranquility" as "ensure peace" etc.,
      # so we accept any of the keyword tokens individually.
      must_contain_any=[
          "more perfect", "perfect union", "stronger union",
          "establish justice", "justice",
          "domestic tranquility", "domestic tranquillity", "tranquility",
          "common defence", "common defense", "defence", "defense",
          "general welfare", "welfare",
          "blessings of liberty", "liberty", "freedom",
          "ordain", "we the people",
      ]),
    Q("T1 basic", "T1.2",
      "How many years is a Senator's term?",
      "factoid",
      must_contain_any=["six", "6"]),
    Q("T1 basic", "T1.3",
      "What is the minimum age to become President?",
      "factoid",
      must_contain_any=["thirty-five", "thirty five", "35"]),

    # Tier 2 - numerical / factual
    Q("T2 numerical", "T2.4",
      "How many states must ratify a constitutional amendment for it to pass?",
      "factoid",
      must_contain_any=["three fourths", "three-fourths", "3/4"]),
    Q("T2 numerical", "T2.5",
      "How many senators does each state get?",
      "factoid",
      must_contain_any=["two", "2"]),
    Q("T2 numerical", "T2.6",
      "What fraction of Congress is needed to override a presidential veto?",
      "factoid",
      must_contain_any=["two thirds", "two-thirds", "2/3"]),

    # Tier 3 - clause-specific
    Q("T3 clause", "T3.7",
      "Which house has the sole power of impeachment?",
      "clause",
      must_contain_any=["house of representatives", "representatives"]),
    Q("T3 clause", "T3.8",
      "Who presides over the Senate when the President is on trial during impeachment?",
      "clause",
      must_contain_any=["chief justice"]),
    Q("T3 clause", "T3.9",
      "What are the only two ways treason can be proven under the Constitution?",
      "clause",
      must_contain_any=["two witnesses", "confession", "open court"]),

    # Tier 4 - inference / reasoning
    Q("T4 reasoning", "T4.10",
      "Can a sitting U.S. Senator be appointed as a presidential elector? Why or why not?",
      "reasoning",
      # Article II, Section 1: "no Senator or Representative ... shall be appointed an Elector".
      must_contain_any=[
          "no senator", "no senator or representative",
          "shall not", "cannot", "may not",
          "ineligible", "not be appointed", "prohibited",
      ]),
    Q("T4 reasoning", "T4.11",
      "If the President neither signs nor vetoes a bill within 10 days, what happens?",
      "reasoning",
      # Article I, Sec 7: "the same shall be a law, in like manner as if he had signed it"
      # (unless Congress by adjournment prevents return -> pocket veto).
      must_contain_any=[
          "shall be a law", "becomes a law", "becomes law",
          "in like manner", "as if he had signed",
      ]),
    Q("T4 reasoning", "T4.12",
      "What happens if no presidential candidate wins a majority of electoral votes?",
      "reasoning",
      # Article II (the 1787 text in this PDF) uses the archaic spelling
      # "chuse" and says "from the five highest on the List".
      # Modern paraphrases use "choose"/"select" and "from the persons having".
      must_contain_any=[
          "house of representatives", "house shall",
          "chuse", "choose", "shall choose", "shall in like manner",
          "in like manner",
          "from the five highest", "five highest", "from the list",
          "from the persons",
      ]),

    # Tier 5 - edge / hallucination probe
    # Both of these are "expected: No / None". The model can satisfy them
    # either by an explicit negative answer ("does not mention", "none")
    # OR by emitting our canned NOT_FOUND refusal.
    Q("T5 edge", "T5.13",
      "Does the Constitution mention political parties?",
      "edge",
      accept_refuse=True,
      must_contain_any=[
          "does not mention", "doesn't mention", "no mention",
          "not mentioned", "does not contain", "no reference",
      ]),
    Q("T5 edge", "T5.14",
      "How many amendments are included in this document?",
      "edge",
      accept_refuse=True,
      must_contain_any=[
          "none", "no amendments", "zero",
          "not included", "does not include", "no amendments are included",
      ]),
]


def _post(question: str, session_id: str | None) -> dict:
    body = {"question": question}
    if session_id:
        body["session_id"] = session_id
    payload = json.dumps(body).encode("utf-8")
    req = Request(API_URL, data=payload, headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=TIMEOUT_S) as r:
        return json.loads(r.read().decode("utf-8"))


def _verdict(q: Q, answer: str) -> tuple[str, str]:
    a = (answer or "").lower()
    refused = NOT_FOUND.lower() in a
    if q.must_refuse:
        if refused:
            return "PASS", "correctly refused"
        return "FAIL", f"expected refusal, got: {answer[:200]}"
    if q.accept_refuse:
        if refused:
            return "PASS", "refused (acceptable for this edge case)"
        if q.must_contain_any:
            hits = [k for k in q.must_contain_any if k.lower() in a]
            if hits:
                return "PASS", f"matched negative phrasing: {hits!r}"
            return "FAIL", (
                f"expected refusal or one of {q.must_contain_any!r}; "
                f"got: {answer[:200]}"
            )
        return "INFO", "no automatic check"
    if q.must_contain_any:
        hits = [k for k in q.must_contain_any if k.lower() in a]
        if not hits:
            return "FAIL", f"none of {q.must_contain_any!r} present"
        if len(hits) == 1 and q.expect_kind in {"synthesis", "reasoning"}:
            return "WEAK", f"only matched: {hits!r}"
        return "PASS", f"matched: {hits!r}"
    return "INFO", "no automatic check"


def _filter_questions(tiers: list[str] | None, limit: int | None) -> list[Q]:
    qs = QUESTIONS
    if tiers:
        wanted = {t.strip().upper() for t in tiers if t.strip()}
        qs = [q for q in qs if q.qid.split(".")[0] in wanted]
    if limit is not None and limit > 0:
        qs = qs[:limit]
    return qs


def main() -> int:
    parser = argparse.ArgumentParser(description="RAG NXP test runner.")
    parser.add_argument(
        "--tiers",
        type=lambda s: s.split(","),
        default=None,
        help="Comma-separated tier prefixes to run (e.g. T1,T2). Default: all.",
    )
    parser.add_argument(
        "--limit", type=int, default=None,
        help="Run at most N questions (after tier filter).",
    )
    args = parser.parse_args()

    selected = _filter_questions(args.tiers, args.limit)
    if not selected:
        print(f"No questions matched filter: tiers={args.tiers!r} limit={args.limit!r}", file=sys.stderr)
        return 2

    out_md = Path("test_results.md")
    out_json = Path("test_results.json")
    raw_results: list[dict] = []
    md_lines: list[str] = [
        "# RAG NXP test run\n",
        f"Endpoint: `{API_URL}`\n",
        f"Filter: tiers={args.tiers or 'ALL'} limit={args.limit or 'none'} "
        f"({len(selected)} of {len(QUESTIONS)} questions)\n",
    ]
    summary: dict[str, list[str]] = {"PASS": [], "WEAK": [], "FAIL": [], "INFO": [], "ERROR": []}

    started = time.time()
    for i, q in enumerate(selected, start=1):
        print(f"[{i:02d}/{len(selected)}] {q.qid} {q.question[:60]!r}", flush=True)
        t0 = time.time()
        try:
            data = _post(q.question, q.session_id)
            ans = data.get("answer", "")
            sources = data.get("sources", []) or []
            verdict, why = _verdict(q, ans)
        except (HTTPError, URLError, TimeoutError, ConnectionError) as e:
            data = {"error": str(e)}
            ans = ""
            sources = []
            verdict, why = "ERROR", f"network: {e}"
        elapsed = time.time() - t0
        summary.setdefault(verdict, []).append(q.qid)
        print(f"      -> {verdict} ({elapsed:.1f}s) {why}", flush=True)

        md_lines.append(f"\n## {q.qid} [{verdict}] ({elapsed:.1f}s) - {q.tier}\n")
        md_lines.append(f"**Q:** {q.question}\n")
        md_lines.append(f"**A:** {ans or '(no answer)'}\n")
        md_lines.append(f"**Verdict reason:** {why}\n")
        if sources:
            md_lines.append("\n**Retrieved chunks (page hints):**\n")
            for s in sources:
                tag = s.get("page_hint") or "?"
                md_lines.append(f"- [{s.get('rank')}] {tag} — dist={s.get('distance')}\n")
        raw_results.append({"q": q.qid, "question": q.question, "tier": q.tier,
                            "verdict": verdict, "reason": why, "elapsed_s": elapsed,
                            "response": data})
        out_md.write_text("".join(md_lines), encoding="utf-8")
        out_json.write_text(json.dumps(raw_results, indent=2), encoding="utf-8")

    total = time.time() - started
    md_lines.append("\n## Summary\n")
    for k in ("PASS", "WEAK", "FAIL", "ERROR", "INFO"):
        ids = summary.get(k, [])
        md_lines.append(f"- {k}: {len(ids)} {ids}\n")
    md_lines.append(f"\nTotal time: {total:.1f}s\n")
    out_md.write_text("".join(md_lines), encoding="utf-8")
    print("\n=== SUMMARY ===")
    for k in ("PASS", "WEAK", "FAIL", "ERROR", "INFO"):
        print(f"{k:5s}: {len(summary.get(k, []))} {summary.get(k, [])}")
    print(f"Total: {total:.1f}s. See {out_md} and {out_json}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
